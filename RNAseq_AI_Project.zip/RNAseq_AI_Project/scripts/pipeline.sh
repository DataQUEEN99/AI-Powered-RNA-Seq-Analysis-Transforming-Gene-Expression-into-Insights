#!/bin/bash

echo "🚀 RNA-seq Pipeline Started"

# QC
fastqc ../data/raw/sample.fastq -o ../qc/

# Dummy alignment (skip if no reference)
echo "Skipping alignment for demo"

echo "✅ Pipeline Finished"
