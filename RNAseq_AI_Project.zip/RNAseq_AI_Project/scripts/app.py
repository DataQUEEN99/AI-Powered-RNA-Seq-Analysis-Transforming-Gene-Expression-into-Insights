import streamlit as st
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.linear_model import LogisticRegression

st.title("🧬 RNA-seq AI Predictor + Visualization")

# Model training (demo)
X = np.array([[10,20,30],[15,25,35],[40,50,60],[45,55,65]])
y = np.array([0,0,1,1])

model = LogisticRegression()
model.fit(X,y)

# Input
g1 = st.number_input("Gene 1", value=10)
g2 = st.number_input("Gene 2", value=20)
g3 = st.number_input("Gene 3", value=30)

if st.button("Predict"):

    data = np.array([g1, g2, g3]).reshape(1, -1)

    pred = model.predict(data)
    result = "Disease" if pred[0]==1 else "Normal"

    st.success(f"Prediction: {result}")

    # ---------------- VISUALS ---------------- #

    st.subheader("📊 Gene Expression Bar Chart")
    fig1, ax1 = plt.subplots()
    ax1.bar(["Gene1","Gene2","Gene3"], [g1,g2,g3])
    st.pyplot(fig1)

    st.subheader("📈 Line Plot")
    fig2, ax2 = plt.subplots()
    ax2.plot([g1,g2,g3], marker='o')
    ax2.set_xticks([0,1,2])
    ax2.set_xticklabels(["Gene1","Gene2","Gene3"])
    st.pyplot(fig2)

    st.subheader("📉 Distribution (Histogram)")
    fig3, ax3 = plt.subplots()
    ax3.hist([g1,g2,g3], bins=5)
    st.pyplot(fig3)

    st.subheader("🔥 Heatmap")
    fig4, ax4 = plt.subplots()
    sns.heatmap([[g1,g2,g3]], annot=True, cmap="coolwarm", ax=ax4)
    st.pyplot(fig4)

    st.subheader("📦 Box Plot")
    fig5, ax5 = plt.subplots()
    ax5.boxplot([g1,g2,g3])
    st.pyplot(fig5)
