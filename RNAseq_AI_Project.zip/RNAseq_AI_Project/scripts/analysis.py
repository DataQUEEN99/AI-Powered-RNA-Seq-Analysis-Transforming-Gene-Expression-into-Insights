import pandas as pd
import numpy as np

print("RNA-seq Analysis Started")

data = [10, 20, 30, 40]

print("Mean:", np.mean(data))
