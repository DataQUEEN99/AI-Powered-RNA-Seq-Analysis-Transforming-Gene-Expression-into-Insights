import numpy as np
from sklearn.linear_model import LogisticRegression

# Fake gene expression data
X = np.array([
    [10, 20, 30],
    [15, 25, 35],
    [40, 50, 60],
    [45, 55, 65]
])

# Labels (0 = normal, 1 = disease)
y = np.array([0, 0, 1, 1])

model = LogisticRegression()
model.fit(X, y)

# Predict new sample
new_sample = [[20, 30, 40]]
prediction = model.predict(new_sample)

print("Prediction:", "Disease" if prediction[0]==1 else "Normal")
